import React from "react";
import MainImage from "./components/MainImage";
import Backgrounds from "./components/traits/Backgrounds";

function App() {
  return (
    <div className='App'>
      {/* Trait selection components */}
      <Backgrounds />
      {/* ... other trait components */}

      {/* Main Image Display */}
      <MainImage />
    </div>
  );
}

export default App;
