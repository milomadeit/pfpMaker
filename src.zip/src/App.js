import React from "react";
import MainImage from "./components/MainImage";
import Backgrounds from "./components/traits/Backgrounds";
import BodyType from "./components/traits/Body";
import Eyes from "./components/traits/Eyes";
import HairHats from "./components/traits/Hair+Hats";
function App() {
  return (
    <div className='App'>
      {/* Trait selection components */}
      <Backgrounds />
      {""}
      {/* ... other trait components */}
      <BodyType />
      {""}
      <Eyes />
      {""}
      <HairHats />
      {""}
      {/* Main Image Display */}
      <MainImage />
    </div>
  );
}

export default App;
