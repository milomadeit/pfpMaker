import React from "react";
import { useSelector } from "react-redux";
import "./MainImage.css";

// 1. Import your backgrounds
import Concrete from "../assets/Background/Concrete.png";
import Lavender from "../assets/Background/Lavender.png";
import Mint from "../assets/Background/Mint.png";
import OrangeCream from "../assets/Background/OrangeCream.png";
import Peach from "../assets/Background/Peach.png";
import Sky from "../assets/Background/Sky.png";

function MainImage() {
  const traits = useSelector((state) => state.traits);

  // 2. Create a mapping object
  const backgroundsMapping = {
    Concrete: Concrete,
    Lavender: Lavender,
    Mint: Mint,
    OrangeCream: OrangeCream,
    Peach: Peach,
    Sky: Sky,
    // Add more mappings as needed
  };

  // 3. Use this mapping to get the image source
  const imageSrc = backgroundsMapping[traits.background];
  console.log(imageSrc);

  return (
    <div className='imageContainer'>
      <img src={imageSrc} alt='Background Layer' className='imageLayer' />
      {/* ... other trait layers */}
    </div>
  );
}

export default MainImage;
